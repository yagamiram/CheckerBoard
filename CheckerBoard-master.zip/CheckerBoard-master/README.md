# CheckerBoard
This is a repo for CheckerBoard - Robotics Challenge
