require('coffee-script').register();
require('./application')

